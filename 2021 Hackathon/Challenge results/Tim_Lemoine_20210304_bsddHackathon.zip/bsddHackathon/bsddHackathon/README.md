﻿# GraphQL Example in ASP.NET Core in .NET 5

This example demonstrates how to use the GraphQL endpoint to access the bsDD API.