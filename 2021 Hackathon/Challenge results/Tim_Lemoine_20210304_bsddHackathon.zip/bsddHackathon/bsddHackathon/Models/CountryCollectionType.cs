﻿using System.Collections.Generic;

namespace bsddHackathon.Models
{
    public class CountryCollectionType
    {
        public IReadOnlyList<Country> Countries { get; set; }
    }
}
