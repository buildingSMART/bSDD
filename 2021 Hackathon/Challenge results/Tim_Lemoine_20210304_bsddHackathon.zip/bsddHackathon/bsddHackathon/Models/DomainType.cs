﻿namespace bsddHackathon.Models
{
    public class DomainType
    {
        public Domain Domain { get; set; }
    }
}
