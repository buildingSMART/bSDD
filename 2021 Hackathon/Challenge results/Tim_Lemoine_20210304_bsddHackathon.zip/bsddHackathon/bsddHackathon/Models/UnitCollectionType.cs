﻿using System.Collections.Generic;

namespace bsddHackathon.Models
{
    public class UnitCollectionType
    {
        public IReadOnlyList<Unit> Units { get; set; }
    }
}
