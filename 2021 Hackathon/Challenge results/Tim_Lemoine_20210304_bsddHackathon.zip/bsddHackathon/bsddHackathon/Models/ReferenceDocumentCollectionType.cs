﻿using System.Collections.Generic;

namespace bsddHackathon.Models
{
    public class ReferenceDocumentCollectionType
    {
        public IReadOnlyList<ReferenceDocument> ReferenceDocuments { get; set; }
    }
}
