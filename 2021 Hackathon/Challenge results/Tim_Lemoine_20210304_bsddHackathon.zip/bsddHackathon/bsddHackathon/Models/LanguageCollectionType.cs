﻿using System.Collections.Generic;

namespace bsddHackathon.Models
{
    public class LanguageCollectionType
    {
        public IReadOnlyList<Language> Languages { get; set; }
    }
}
