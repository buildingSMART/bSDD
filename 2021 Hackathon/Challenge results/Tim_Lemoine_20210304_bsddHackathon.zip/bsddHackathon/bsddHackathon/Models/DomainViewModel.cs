﻿namespace bsddHackathon.Models
{
    public class DomainViewModel
    {
        public Domain Domain { get; set; }
    }
}
