﻿using System.Collections.Generic;

namespace bsddHackathon.Models
{
    public class DomainCollectionType
    {
        public IReadOnlyList<Domain> Domains { get; set; }
    }
}
